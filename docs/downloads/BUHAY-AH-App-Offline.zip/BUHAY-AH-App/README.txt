BUHAY-AH App (offline package) v1.1
Design, quote and check public buildings and bridges.

How to use
1. Extract this ZIP.
2. Open BUHAY-AH-App/index.html in any modern browser (Chrome, Edge, Firefox, Safari).
3. Design from a template, a requirement or a budget; quote a plan; check a contract.
   Everything runs on your device without internet.

Screens
- Home: start points and the current plan.
- Design: 41 building and 13 bridge templates, design from requirements, design from a budget,
  bridge designer; edit, save, combine designs and export floor plans as SVG.
- Quote: lean start quotation, standard fair estimate and ceiling, ABC breakdown,
  bill of quantities, DXF/JSON plan import, 3D model.
- Check: over-budget ratio, XGBoost expectation, Isolation Forest, BUHAY-AH Risk Index,
  SHAP explanation, markup and line-item checks.
- Library: reference plans, saved plans and designs, editable unit price book.

Notes
- Generated designs are schematic and for estimating only. They must be developed and signed
  by licensed architects and engineers.
- A flag is a reason to review, not proof of wrongdoing.
- Results reported in the research are from a simulated benchmark (SBD-300).

Lead Researcher: Enrique Miguel C. Buban
