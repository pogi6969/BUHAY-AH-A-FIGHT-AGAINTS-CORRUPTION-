BUHAY — Buildings-and-Bridges Unit-cost Hybrid Analytics and Yardstick
Offline package v1.0 · Lead researcher: Enrique Miguel C. Buban

How to use
1. Extract this ZIP anywhere on your computer.
2. Open index.html in Chrome, Edge, Firefox or Safari.
3. Quote a building or bridge, check a contract, open the map.

Everything runs on your device. Street map tiles and web fonts load only when you are online;
province boundaries, quotations, checks and the models work without internet.

The demo map pins are a simulated research benchmark (SBD-300), not real DPWH contracts.
A flag is a screening signal for review, not proof of wrongdoing.
